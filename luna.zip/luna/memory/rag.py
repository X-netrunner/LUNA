import hashlib
import os
import sys
import uuid

import chromadb
from chromadb.utils import embedding_functions

# Persistent DB (important)
# Create directory if it doesn't exist
os.makedirs("memory/chroma_db", exist_ok=True)

# ------------------------------
# Explicit embedding function
# Faster + deterministic local embeddings
# ------------------------------
embedding_function = None


def get_embedding_function():
    global embedding_function
    if embedding_function is None:
        from chromadb.utils import embedding_functions

        embedding_function = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name="all-MiniLM-L6-v2"
        )
    return embedding_function


client = chromadb.PersistentClient(path="memory/chroma_db")

collection = client.get_or_create_collection(
    name="memory", embedding_function=get_embedding_function()
)


def add_entry(text):
    """
    Adds memory with hash-based ID to prevent duplicates.
    """
    if not text.strip():
        return

    # Prevent duplicates using hash
    doc_id = hashlib.sha256(text.encode()).hexdigest()

    collection.upsert(documents=[text], ids=[doc_id])

    print("Stored in vector memory.")


def query(text, top_k=1, similarity_threshold=0.8):
    """
    Query memory with similarity threshold filtering.
    """
    if not text.strip():
        return

    results = collection.query(
        query_texts=[text], n_results=top_k, include=["documents", "distances"]
    )

    docs = results.get("documents", [[]])[0]
    distances = results.get("distances", [[]])[0]

    if not docs:
        print("No memory yet.")
        return

    relevant_docs = []

    for doc, dist in zip(docs, distances):
        if dist is not None and dist < similarity_threshold:
            relevant_docs.append(doc)

    if not relevant_docs:
        print("No relevant memory found.")
        return

    for i, doc in enumerate(relevant_docs):
        print(f"[MEMORY {i + 1}] {doc}")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(0)

    mode = sys.argv[1]

    # Support multi-word memory text
    text = " ".join(sys.argv[2:])

    if mode == "add":
        add_entry(text)

    elif mode == "query":
        query(text)
