import os
import sys
import uuid

import chromadb

# Persistent DB (important)
# Create directory if it doesn't exist
os.makedirs("memory/chroma_db", exist_ok=True)

client = chromadb.PersistentClient(path="memory/chroma_db")

collection = client.get_or_create_collection("memory")


def add_entry(text):
    collection.add(documents=[text], ids=[str(uuid.uuid4())])
    print("Stored in vector memory.")


def query(text, top_k=3):
    results = collection.query(query_texts=[text], n_results=top_k)

    docs = results.get("documents", [[]])[0]

    if not docs:
        print("No memory yet.")
        return

    for i, doc in enumerate(docs):
        print(f"[MEMORY {i + 1}] {doc}")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(0)

    mode = sys.argv[1]
    text = sys.argv[2]

    if mode == "add":
        add_entry(text)

    elif mode == "query":
        query(text)
